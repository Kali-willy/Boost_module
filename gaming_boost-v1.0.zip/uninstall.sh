#!/system/bin/sh
# This script will be executed when Magisk removes the module

# Your cleanup code goes here

# Log to Magisk log
LOGFILE=/cache/magisk.log
if [ -f "$LOGFILE" ]; then
  echo "Android 10+ Module: Uninstall script executed successfully" >> $LOGFILE
fi 