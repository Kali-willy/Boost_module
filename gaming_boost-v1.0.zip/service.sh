#!/system/bin/sh
# This script will be executed in late_start service mode
# More info in the Magisk documentation

MODDIR=${0%/*}
SAFETY_FILE="$MODDIR/safety_boot"

# Signal successful boot - reset boot counter if it exists
if [ -f "$SAFETY_FILE" ]; then
    echo "0" > "$SAFETY_FILE"
fi

# Check if we should apply aggressive tweaks
AGGRESSIVE_MODE=false
# Get the Android version
SDK_VERSION=$(getprop ro.build.version.sdk)

# Only apply aggressive tweaks on Android 11 (SDK 30) and above
if [ "$SDK_VERSION" -ge 30 ]; then
    AGGRESSIVE_MODE=true
fi

# Performance tweaks for gaming - with check for each system file
# CPU Boost - with device compatibility check
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
do
    if [ -e "$cpu" ]; then
        # Use a slightly safer governor if available
        echo "schedutil" > "$cpu" 2>/dev/null || 
        echo "interactive" > "$cpu" 2>/dev/null || 
        echo "performance" > "$cpu" 2>/dev/null
    fi
done

# Set CPU minimum frequency - safely
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq
do
    if [ -e "$cpu" ]; then
        # Read current value first
        CURRENT_MIN=$(cat "$cpu")
        # Get max frequency
        MAX_FREQ_FILE=$(echo "$cpu" | sed 's/min/max/')
        if [ -e "$MAX_FREQ_FILE" ]; then
            MAX_FREQ=$(cat "$MAX_FREQ_FILE")
            # Set to 40% of max frequency instead of hardcoded value
            TARGET_FREQ=$((MAX_FREQ / 5 * 2))
            # Only set if target is higher than current
            if [ "$TARGET_FREQ" -gt "$CURRENT_MIN" ]; then
                echo "$TARGET_FREQ" > "$cpu" 2>/dev/null
            fi
        fi
    fi
done

# Disable thermal throttling only in aggressive mode
if [ "$AGGRESSIVE_MODE" = true ]; then
    if [ -e "/sys/module/msm_thermal/core_control/enabled" ]; then
        echo "0" > /sys/module/msm_thermal/core_control/enabled
    fi
fi

# GPU performance optimization
# Run our comprehensive GPU optimizer with safety
if [ -f "$MODDIR/system/bin/gpu_optimize.sh" ]; then
    # Run with appropriate mode parameter
    sh "$MODDIR/system/bin/gpu_optimize.sh" "$AGGRESSIVE_MODE"
else
    # Fallback to basic GPU tweaks if script not found
    # Apply safer tweaks
    if [ -e "/sys/class/kgsl/kgsl-3d0/devfreq/governor" ]; then
        if [ "$AGGRESSIVE_MODE" = true ]; then
            echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
        else
            echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null ||
            echo "simple_ondemand" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
        fi
    fi
    
    # Only force components on in aggressive mode
    if [ "$AGGRESSIVE_MODE" = true ]; then
        if [ -e "/sys/class/kgsl/kgsl-3d0/force_clk_on" ]; then
            echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
        fi
        if [ -e "/sys/class/kgsl/kgsl-3d0/force_bus_on" ]; then
            echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on
        fi
        if [ -e "/sys/class/kgsl/kgsl-3d0/force_rail_on" ]; then
            echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on
        fi
    fi
    
    if [ -e "/sys/class/kgsl/kgsl-3d0/idle_timer" ]; then
        echo "100000" > /sys/class/kgsl/kgsl-3d0/idle_timer
    fi
    
    # Safe power level settings
    if [ -e "/sys/class/kgsl/kgsl-3d0/min_pwrlevel" ]; then
        # For min, use a safer higher number (lower performance)
        echo "1" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel
    fi
    if [ -e "/sys/class/kgsl/kgsl-3d0/max_pwrlevel" ]; then
        # For max, use 0 (max performance)
        echo "0" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel
    fi
fi

# VM improvements - with safety checks
if [ -e "/proc/sys/vm/swappiness" ]; then
    echo "60" > /proc/sys/vm/swappiness
fi
if [ -e "/proc/sys/vm/vfs_cache_pressure" ]; then
    echo "80" > /proc/sys/vm/vfs_cache_pressure
fi
if [ -e "/proc/sys/kernel/random/read_wakeup_threshold" ]; then
    echo "128" > /proc/sys/kernel/random/read_wakeup_threshold
fi
if [ -e "/proc/sys/kernel/random/write_wakeup_threshold" ]; then
    echo "256" > /proc/sys/kernel/random/write_wakeup_threshold
fi

# Kernel tweaks - only in aggressive mode
if [ "$AGGRESSIVE_MODE" = true ]; then
    if [ -e "/proc/sys/kernel/sched_schedstats" ]; then
        echo "0" > /proc/sys/kernel/sched_schedstats
    fi
fi

# I/O scheduler optimization - less aggressive
for queue in /sys/block/*/queue
do
    # Use cfq or deadline based on availability
    if [ -e "${queue}/scheduler" ]; then
        echo "cfq" > "${queue}/scheduler" 2>/dev/null || 
        echo "deadline" > "${queue}/scheduler" 2>/dev/null
    fi
    
    # More moderate read ahead
    if [ -e "${queue}/read_ahead_kb" ]; then
        echo "1024" > "${queue}/read_ahead_kb"
    fi
    
    # Moderate nr_requests
    if [ -e "${queue}/nr_requests" ]; then
        echo "128" > "${queue}/nr_requests"
    fi
done

# Create a file to indicate gaming mode is not active by default
if [ ! -f "$MODDIR/gaming_mode" ]; then
    # Not in gaming mode by default (safer)
    touch "$MODDIR/normal_mode"
fi

# Log to Magisk log
LOGFILE=/cache/magisk.log
if [ -f "$LOGFILE" ]; then
    echo "Gaming Boost Module: Performance tweaks applied successfully with bootloop protection" >> $LOGFILE
    if [ "$AGGRESSIVE_MODE" = true ]; then
        echo "Gaming Boost Module: Aggressive mode enabled (Android 11+)" >> $LOGFILE
    else
        echo "Gaming Boost Module: Safe mode enabled (Android 10)" >> $LOGFILE
    fi
fi 