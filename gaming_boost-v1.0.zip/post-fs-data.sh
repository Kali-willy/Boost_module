#!/system/bin/sh
# This script will be executed in post-fs-data mode
# More info in the Magisk documentation

MODDIR=${0%/*}
BOOTLOOP_PROTECTION=true
SAFETY_FILE="$MODDIR/safety_boot"
MAX_BOOT_COUNT=3
CURRENT_BOOT=0

# Boot safety check
if [ "$BOOTLOOP_PROTECTION" = true ]; then
    # Create safety file if it doesn't exist
    if [ ! -f "$SAFETY_FILE" ]; then
        echo "1" > "$SAFETY_FILE"
        CURRENT_BOOT=1
    else
        CURRENT_BOOT=$(cat "$SAFETY_FILE")
        CURRENT_BOOT=$((CURRENT_BOOT + 1))
        echo "$CURRENT_BOOT" > "$SAFETY_FILE"
    fi
    
    # If we've booted too many times without completing boot, disable module
    if [ "$CURRENT_BOOT" -gt "$MAX_BOOT_COUNT" ]; then
        # Create disable file to disable module
        touch "$MODDIR/disable"
        echo "Gaming Boost Module: Too many unsuccessful boots, disabling module" > /dev/kmsg
        echo "0" > "$SAFETY_FILE"
        exit 0
    fi
fi

# Early performance tweaks - using safer values
# Disable mpdecision if it exists - with safety check
if [ -e "/system/bin/mpdecision" ]; then
    # Don't stop on first boot in case it causes issues
    if [ "$CURRENT_BOOT" -gt 1 ]; then
        stop mpdecision
    fi
fi

# Disable thermal engine with safety check
if [ -e "/system/bin/thermal-engine" ]; then
    # Don't stop on first boot in case it causes issues
    if [ "$CURRENT_BOOT" -gt 1 ]; then
        stop thermal-engine
    fi
fi

# Memory management improvements - safer values
if [ -e "/proc/sys/vm/dirty_ratio" ]; then
    echo "20" > /proc/sys/vm/dirty_ratio
fi
if [ -e "/proc/sys/vm/dirty_background_ratio" ]; then
    echo "10" > /proc/sys/vm/dirty_background_ratio
fi
if [ -e "/proc/sys/vm/dirty_expire_centisecs" ]; then
    echo "3000" > /proc/sys/vm/dirty_expire_centisecs
fi
if [ -e "/proc/sys/vm/dirty_writeback_centisecs" ]; then
    echo "500" > /proc/sys/vm/dirty_writeback_centisecs
fi

# Network improvements for online gaming - safer values
# Only apply if not first boot
if [ "$CURRENT_BOOT" -gt 1 ]; then
    if [ -e "/proc/sys/net/ipv4/tcp_timestamps" ]; then
        echo "0" > /proc/sys/net/ipv4/tcp_timestamps
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_tw_reuse" ]; then
        echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_sack" ]; then
        echo "1" > /proc/sys/net/ipv4/tcp_sack
    fi
    # Removed tcp_tw_recycle as it can cause issues
    if [ -e "/proc/sys/net/ipv4/tcp_window_scaling" ]; then
        echo "1" > /proc/sys/net/ipv4/tcp_window_scaling
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_keepalive_probes" ]; then
        echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_keepalive_intvl" ]; then
        echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_fin_timeout" ]; then
        echo "30" > /proc/sys/net/ipv4/tcp_fin_timeout
    fi
    if [ -e "/proc/sys/net/core/wmem_max" ]; then
        echo "404480" > /proc/sys/net/core/wmem_max
    fi
    if [ -e "/proc/sys/net/core/rmem_max" ]; then
        echo "404480" > /proc/sys/net/core/rmem_max
    fi
    if [ -e "/proc/sys/net/core/rmem_default" ]; then
        echo "256960" > /proc/sys/net/core/rmem_default
    fi
    if [ -e "/proc/sys/net/core/wmem_default" ]; then
        echo "256960" > /proc/sys/net/core/wmem_default
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_wmem" ]; then
        echo "4096 16384 404480" > /proc/sys/net/ipv4/tcp_wmem
    fi
    if [ -e "/proc/sys/net/ipv4/tcp_rmem" ]; then
        echo "4096 87380 404480" > /proc/sys/net/ipv4/tcp_rmem
    fi
fi

# Additional GPU tweaks - safer approach
if [ -e "/sys/class/kgsl/kgsl-3d0/default_pwrlevel" ]; then
    # Use a safer value (not 0) to prevent overheating
    echo "1" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
fi

# Signal successful boot completion
# This will be handled in service.sh after complete boot

# Log to Magisk log
LOGFILE=/cache/magisk.log
if [ -f "$LOGFILE" ]; then
    echo "Gaming Boost Module: Early performance tweaks applied successfully (Boot #$CURRENT_BOOT)" >> $LOGFILE
fi 