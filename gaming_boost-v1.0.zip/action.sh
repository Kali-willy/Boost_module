#!/system/bin/sh
# This script will be executed when the user clicks the action button in Magisk app

MODDIR=${0%/*}
MODE_FLAG="$MODDIR/gaming_mode"
NORMAL_FLAG="$MODDIR/normal_mode"
SAFETY_FLAG="$MODDIR/safety_boot"

# Get device info
DEVICE=$(getprop ro.product.model)
SDK_VERSION=$(getprop ro.build.version.sdk)

# Determine if we should use aggressive mode
AGGRESSIVE_MODE=false
if [ "$SDK_VERSION" -ge 30 ]; then
    AGGRESSIVE_MODE=true
fi

# Safety check function to verify system access
check_system_access() {
    # Try to access a critical system path
    if ! cat /proc/version > /dev/null 2>&1; then
        su -lp 2000 -c "cmd notification post -S bigtext -t 'Gaming Boost' 'Tag' 'Error: Cannot access system. Please check Magisk permissions.'"
        echo "Gaming Boost Module: Cannot access system" > /dev/kmsg
        return 1
    fi
    return 0
}

# Ensure we can access system before continuing
if ! check_system_access; then
    exit 1
fi

# Reset safety boot counter - this proves user interaction is working
if [ -f "$SAFETY_FLAG" ]; then
    echo "0" > "$SAFETY_FLAG"
fi

# Check current mode
if [ -f "$MODE_FLAG" ]; then
    # Switch to normal mode
    rm -f "$MODE_FLAG"
    touch "$NORMAL_FLAG"
    
    # Reset CPU governors safely
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
    do
        if [ -e "$cpu" ]; then
            # Try different governors based on what's available
            echo "schedutil" > $cpu 2>/dev/null || 
            echo "interactive" > $cpu 2>/dev/null || 
            echo "ondemand" > $cpu 2>/dev/null
        fi
    done
    
    # Reset GPU governor safely
    if [ -e "/sys/class/kgsl/kgsl-3d0/devfreq/governor" ]; then
        echo "msm-adreno-tz" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null ||
        echo "simple_ondemand" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 2>/dev/null
    fi
    
    # Enable thermal controls again
    if [ -e "/sys/module/msm_thermal/core_control/enabled" ]; then
        echo "1" > /sys/module/msm_thermal/core_control/enabled
    fi
    
    # Reset GPU settings safely
    if [ -e "/sys/class/kgsl/kgsl-3d0/force_clk_on" ]; then
        echo "0" > /sys/class/kgsl/kgsl-3d0/force_clk_on
    fi
    if [ -e "/sys/class/kgsl/kgsl-3d0/force_bus_on" ]; then
        echo "0" > /sys/class/kgsl/kgsl-3d0/force_bus_on
    fi
    if [ -e "/sys/class/kgsl/kgsl-3d0/force_rail_on" ]; then
        echo "0" > /sys/class/kgsl/kgsl-3d0/force_rail_on
    fi
    
    # Restart thermal services
    if [ -e "/system/bin/thermal-engine" ]; then
        # Try to start thermal engine
        start thermal-engine > /dev/null 2>&1
    fi
    
    # Show notification
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Gaming Boost' 'Tag' 'Normal mode activated. Battery saving optimizations enabled.'"
    
    # Log mode change
    echo "Gaming Boost Module: Switched to NORMAL mode" > /dev/kmsg
else
    # Switch to gaming mode
    touch "$MODE_FLAG"
    rm -f "$NORMAL_FLAG"
    
    # Apply performance tweaks with safety checks
    # CPU Boost
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
    do
        if [ -e "$cpu" ]; then
            if [ "$AGGRESSIVE_MODE" = true ]; then
                echo "performance" > $cpu
            else
                # Use a more balanced governor for older devices
                echo "schedutil" > $cpu 2>/dev/null || 
                echo "interactive" > $cpu 2>/dev/null
            fi
        fi
    done
    
    # GPU performance with safety check
    if [ -e "/sys/class/kgsl/kgsl-3d0/devfreq/governor" ]; then
        echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
    fi
    
    # Disable thermal throttling with safety check
    if [ "$AGGRESSIVE_MODE" = true ]; then
        if [ -e "/sys/module/msm_thermal/core_control/enabled" ]; then
            echo "0" > /sys/module/msm_thermal/core_control/enabled
        fi
        
        # Stop thermal services only in aggressive mode
        if [ -e "/system/bin/thermal-engine" ]; then
            stop thermal-engine > /dev/null 2>&1
        fi
    fi
    
    # Run GPU optimizer if available
    if [ -f "$MODDIR/system/bin/gpu_optimize.sh" ]; then
        sh "$MODDIR/system/bin/gpu_optimize.sh" "$AGGRESSIVE_MODE"
    fi
    
    # Show notification
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Gaming Boost' 'Tag' 'Gaming mode activated. Performance optimizations enabled!'"
    
    # Log mode change
    echo "Gaming Boost Module: Switched to GAMING mode" > /dev/kmsg
fi

# Log to Magisk log
LOGFILE=/cache/magisk.log
if [ -f "$LOGFILE" ]; then
    if [ -f "$MODE_FLAG" ]; then
        echo "Gaming Boost Module: Switched to GAMING mode (Aggressive: $AGGRESSIVE_MODE)" >> $LOGFILE
    else
        echo "Gaming Boost Module: Switched to NORMAL mode" >> $LOGFILE
    fi
fi 